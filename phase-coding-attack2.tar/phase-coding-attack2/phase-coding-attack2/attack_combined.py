#!/usr/bin/env python3
"""
CW7: Tan cong ket hop - Resample + MP3 128kbps
Mo phong pipeline YouTube/Facebook/Zalo
"""
import subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
import os

INPUT_WAV   = "stego.wav"
AFTER_RESAMPLE = "temp_resample.wav"
OUTPUT_WAV  = "combined_attack.wav"
BITRATE     = "128"

print("=== Combined Attack: Resample + MP3 {}kbps ===".format(BITRATE))
print("[*] Mo phong pipeline: Upload len mang xa hoi")
print("[*] Buoc 1: Resampling 44100 → 22050 → 44100 Hz...")

rate, audio = wavfile.read(INPUT_WAV)
audio = audio.astype(np.float64)
down = resample_poly(audio, 1, 2)
up   = resample_poly(down, 2, 1)
result = np.clip(up, -32768, 32767).astype(np.int16)
wavfile.write(AFTER_RESAMPLE, rate, result)
print("[*] Resample xong: {}".format(AFTER_RESAMPLE))

print("[*] Buoc 2: MP3 compression {}kbps...".format(BITRATE))
MP3_TEMP = "temp_combined.mp3"
subprocess.run([
    "ffmpeg", "-y", "-i", AFTER_RESAMPLE,
    "-b:a", "{}k".format(BITRATE),
    "-codec:a", "libmp3lame", MP3_TEMP
], capture_output=True)

subprocess.run([
    "ffmpeg", "-y", "-i", MP3_TEMP, OUTPUT_WAV
], capture_output=True)

os.remove(AFTER_RESAMPLE)
os.remove(MP3_TEMP)

rate_out, audio_out = wavfile.read(OUTPUT_WAV)
print("[*] Output: {} Hz, {} samples".format(rate_out, len(audio_out)))
print("[OK] Combined attack: {}".format(OUTPUT_WAV))

print("")
print("[*] Giai thich: Resampling cat tan so > 11025Hz")
print("[*]             MP3 64kbps cat tan so > ~16kHz")  
print("[*]             Tin duoc nhung tai ~17kHz → bi cat boi ca hai")
print("[*]             → BER tuong duong nhau la dung ve ky thuat")
print("[*] Ket hop cho thay: Neu mot tan cong da pha huy, them tan cong kha")
print("[*]                   khong lam BER tang them")
