#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile
import sys

SEGMENT_SIZE = 8192
NUM_CHARS    = 9
START_BIN    = 3200

def bits_to_str(bits):
    chars = []
    for i in range(0, len(bits)-7, 8):
        byte = int(''.join(str(b) for b in bits[i:i+8]), 2)
        chars.append(chr(byte))
    return ''.join(chars)

def phase_extract(audio, num_chars, segment_size, start_bin=START_BIN):
    num_bits = num_chars * 8
    segment  = audio[:segment_size].astype(np.float64)
    fft_data = np.fft.fft(segment)
    phase    = np.angle(fft_data)
    bits = []
    for i in range(num_bits):
        k = start_bin + i
        bits.append(1 if phase[k] >= 0 else 0)
    return bits

if __name__ == "__main__":
    input_file = sys.argv[1] if len(sys.argv) > 1 else "stego.wav"
    rate, audio = wavfile.read(input_file)
    audio = audio.astype(np.float32)
    bits = phase_extract(audio, NUM_CHARS, SEGMENT_SIZE)
    msg  = bits_to_str(bits)
    print("Extracted: '{}'".format(msg))
    print("Bits: {}".format(''.join(str(b) for b in bits)))
