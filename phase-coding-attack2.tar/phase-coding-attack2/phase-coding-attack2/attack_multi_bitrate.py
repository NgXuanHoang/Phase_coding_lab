#!/usr/bin/env python3
"""
So sanh MP3 128kbps vs 64kbps
Ket qua ky vong:
  128kbps → BER ~0.04 (phase coding van song sot mot phan)
   64kbps → BER ~0.68 (phase coding bi pha huy hoan toan)
"""
import subprocess
import os

BITRATES = ["128", "64"]

print("=== So sanh MP3 Bitrate ===")
print("{:<15} {:>8} {:>35}".format("Bitrate", "BER", "Nhan xet"))
print("-" * 60)

results = {}
for br in BITRATES:
    out_wav = "mp3_{}.wav".format(br)
    out_ber = "ber_mp3_{}.txt".format(br)

    subprocess.run(["python3", "attack_mp3.py", br], capture_output=False)
    subprocess.run(["python3", "ber_calculator.py", out_wav,
                    out_ber, "MP3_{}kbps".format(br)], capture_output=False)

    if os.path.exists(out_ber):
        with open(out_ber) as f:
            for line in f:
                if line.startswith("BER="):
                    results[br] = float(line.split("=")[1])
                if line.startswith("NOTE="):
                    note = line.split("=")[1].strip()

print("\n=== Ket luan so sanh ===")
ber_128 = results.get("128", -1)
ber_64  = results.get("64",  -1)
print("MP3 128kbps: BER={:.4f} → {}".format(
    ber_128, "Con doc duoc mot phan" if ber_128 < 0.1 else "Bi anh huong"))
print("MP3  64kbps: BER={:.4f} → {}".format(
    ber_64, "Pha huy hoan toan" if ber_64 > 0.5 else "Con doc duoc"))

if ber_128 < ber_64:
    print("[*] Nhan xet: Bitrate cang thap → BER cang cao → pha huy cang manh")
print("[OK] Multi-bitrate done")
