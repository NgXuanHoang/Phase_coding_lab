#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile
import sys

SEGMENT_SIZE = 8192
MESSAGE      = "ATTT PTIT"
START_BIN    = 3200

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def phase_extract(audio, num_chars, segment_size, start_bin=START_BIN):
    num_bits = num_chars * 8
    segment  = audio[:segment_size].astype(np.float64)
    fft_data = np.fft.fft(segment)
    phase    = np.angle(fft_data)
    bits = []
    for i in range(num_bits):
        k = start_bin + i
        bits.append(1 if phase[k] >= 0 else 0)
    return bits

input_file  = sys.argv[1] if len(sys.argv) > 1 else "stego.wav"
output_file = sys.argv[2] if len(sys.argv) > 2 else "ber_out.txt"
label       = sys.argv[3] if len(sys.argv) > 3 else "Unknown"

rate, audio = wavfile.read(input_file)
orig_bits = str_to_bits(MESSAGE)
recv_bits = phase_extract(audio.astype(np.float32), len(MESSAGE), SEGMENT_SIZE)
errors = sum(o != r for o, r in zip(orig_bits, recv_bits))
ber    = errors / len(orig_bits)

if ber < 0.05:
    note = "Phase coding song sot tot"
elif ber < 0.3:
    note = "Tan cong gay loi nhe"
elif ber < 0.5:
    note = "Tan cong gay loi nghiem trong"
else:
    note = "Phase coding bi pha huy hoan toan"

print("[*] Errors: {}/{}".format(errors, len(orig_bits)))
print("[*] BER: {:.4f} ({:.1f}%)".format(ber, ber*100))
print("[*] Nhan xet: {}".format(note))

with open(output_file, "w") as f:
    f.write("ATTACK={}\n".format(label))
    f.write("BER={:.6f}\n".format(ber))
    f.write("BER_PERCENT={:.2f}\n".format(ber*100))
    f.write("ERRORS={}\n".format(errors))
    f.write("NOTE={}\n".format(note))
print("[OK] BER {}: {:.4f} → {}".format(label, ber, output_file))
