#!/usr/bin/env python3
"""
Tan cong Resampling: 44100 Hz → 22050 Hz → 44100 Hz
Su dung: python3 attack_resample.py [filter]
filter: sinc (mac dinh) | linear | cubic
"""
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly, resample
import sys

INPUT_WAV  = "stego.wav"
FILTER     = sys.argv[1] if len(sys.argv) > 1 else "sinc"

print("=== Resampling Attack ({}) ===".format(FILTER))
rate, audio = wavfile.read(INPUT_WAV)
audio = audio.astype(np.float64)

print("[*] Goc: {} Hz, {} samples".format(rate, len(audio)))
TARGET_RATE = rate // 2  # 44100 → 22050

if FILTER == "sinc":
    # Dung scipy resample_poly (chat luong cao, dung sinc filter)
    down = resample_poly(audio, 1, 2)
    up   = resample_poly(down, 2, 1)
    output_file = "resampled_sinc.wav"
elif FILTER == "linear":
    # Noi suy tuyen tinh - chat luong thap
    x_old = np.linspace(0, 1, len(audio))
    x_new_down = np.linspace(0, 1, len(audio)//2)
    down = np.interp(x_new_down, x_old, audio)
    x_new_up = np.linspace(0, 1, len(audio))
    up   = np.interp(x_new_up, np.linspace(0, 1, len(down)), down)
    output_file = "resampled_linear.wav"
elif FILTER == "cubic":
    from scipy.interpolate import interp1d
    x_old = np.linspace(0, 1, len(audio))
    x_new_down = np.linspace(0, 1, len(audio)//2)
    f_down = interp1d(x_old, audio, kind='cubic')
    down = f_down(x_new_down)
    x_new_up = np.linspace(0, 1, len(audio))
    f_up = interp1d(np.linspace(0, 1, len(down)), down, kind='cubic')
    up   = f_up(x_new_up)
    output_file = "resampled_cubic.wav"
else:
    print("Filter khong hop le! Dung: sinc | linear | cubic")
    exit(1)

# Clip va luu
result = np.clip(up, -32768, 32767).astype(np.int16)
wavfile.write(output_file, rate, result)
print("[*] Down: {} samples ({} Hz)".format(len(down), TARGET_RATE))
print("[*] Up  : {} samples ({} Hz)".format(len(up), rate))
print("[OK] Resampled audio ({}): {}".format(FILTER, output_file))
