#!/usr/bin/env python3
"""
Tan cong MP3 Compression: encode WAV → MP3 → decode ve WAV
Su dung: python3 attack_mp3.py [bitrate]
bitrate: 320 | 128 (mac dinh) | 64 | 32
"""
import subprocess
import sys
import os
from scipy.io import wavfile
import numpy as np

INPUT_WAV = "stego.wav"
BITRATE   = sys.argv[1] if len(sys.argv) > 1 else "128"
MP3_FILE  = "temp_{}.mp3".format(BITRATE)
OUT_WAV   = "mp3_{}.wav".format(BITRATE)

print("=== MP3 Compression Attack ({}kbps) ===".format(BITRATE))

# Encode WAV → MP3
print("[*] Encoding {} → {} kbps MP3...".format(INPUT_WAV, BITRATE))
ret = subprocess.run([
    "ffmpeg", "-y", "-i", INPUT_WAV,
    "-b:a", "{}k".format(BITRATE),
    "-codec:a", "libmp3lame",
    MP3_FILE
], capture_output=True, text=True)

if ret.returncode != 0:
    print("[-] Loi encode MP3!")
    print(ret.stderr[-500:])
    exit(1)

# Decode MP3 → WAV
print("[*] Decoding MP3 → WAV...")
ret2 = subprocess.run([
    "ffmpeg", "-y", "-i", MP3_FILE, OUT_WAV
], capture_output=True, text=True)

if ret2.returncode != 0:
    print("[-] Loi decode MP3!")
    exit(1)

# Kiem tra duration
rate_orig, audio_orig = wavfile.read(INPUT_WAV)
rate_out,  audio_out  = wavfile.read(OUT_WAV)
dur_orig = len(audio_orig) / rate_orig
dur_out  = len(audio_out)  / rate_out

print("[*] Goc  : {:.2f}s ({} Hz)".format(dur_orig, rate_orig))
print("[*] Output: {:.2f}s ({} Hz)".format(dur_out, rate_out))
print("[OK] MP3 {}kbps: {}".format(BITRATE, OUT_WAV))

# Xoa file MP3 tam
os.remove(MP3_FILE)
