#!/usr/bin/env python3
"""Ve do thi BER theo bitrate MP3"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
import subprocess

def read_ber(fname):
    if not os.path.exists(fname):
        return None
    with open(fname) as f:
        for line in f:
            if line.startswith("BER="):
                return float(line.split("=")[1])
    return None

data = {
    "Baseline\n(WAV)":    read_ber("ber_baseline.txt"),
    "Resample\n(sinc)":   read_ber("ber_resample_sinc.txt"),
    "Resample\n(linear)": read_ber("ber_resample_linear.txt"),
    "MP3\n320kbps":       read_ber("ber_mp3_320.txt"),
    "MP3\n128kbps":       read_ber("ber_mp3_128.txt"),
    "MP3\n64kbps":        read_ber("ber_mp3_64.txt"),
    "Combined\nAttack":   read_ber("ber_combined.txt"),
}

labels = [k for k, v in data.items() if v is not None]
values = [v for v in data.values() if v is not None]

if not labels:
    print("Chua co file BER nao! Hay chay cac buoc truoc.")
    exit(1)

colors = []
for v in values:
    if v < 0.1:
        colors.append('#2ecc71')   # xanh la - an toan
    elif v < 0.4:
        colors.append('#f39c12')   # cam - canh bao
    else:
        colors.append('#e74c3c')   # do - nguy hiem

fig, ax = plt.subplots(figsize=(12, 5))
bars = ax.bar(labels, values, color=colors, edgecolor='black', linewidth=0.5)
ax.axhline(y=0.5, color='red', linestyle='--', linewidth=1, label='BER = 0.5 (mat hoan toan)')
ax.axhline(y=0.1, color='green', linestyle='--', linewidth=1, label='BER = 0.1 (nguong an toan)')
ax.set_ylim(0, 1.0)
ax.set_ylabel("Bit Error Rate (BER)", fontsize=11)
ax.set_title("BER theo tung kieu tan cong - Phase Coding Lab 2", fontsize=12, fontweight='bold')
ax.legend(fontsize=9)
ax.grid(True, axis='y', alpha=0.3)

for bar, val in zip(bars, values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
            "{:.3f}".format(val), ha='center', va='bottom', fontsize=9, fontweight='bold')

plt.tight_layout()
plt.savefig("ber_chart.png", dpi=150, bbox_inches='tight')
print("[OK] Da luu: ber_chart.png")
subprocess.Popen(['eog', 'ber_chart.png'])
print("[OK] Da mo do thi BER")
