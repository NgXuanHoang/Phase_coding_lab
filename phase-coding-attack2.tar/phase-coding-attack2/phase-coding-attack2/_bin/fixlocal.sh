#!/bin/bash
pip3 install numpy scipy matplotlib pydub --break-system-packages 2>/dev/null || true
