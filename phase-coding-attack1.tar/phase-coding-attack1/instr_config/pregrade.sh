#!/bin/bash
# pregrade.sh - chay truoc khi grade
# Tham so: $1 = home dir, $2 = container artifact path
cd /home/student/scripts
bash checkwork.sh > /tmp/result.stdout 2>&1
