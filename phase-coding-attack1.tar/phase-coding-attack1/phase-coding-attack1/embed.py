#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile

SEGMENT_SIZE = 8192
MESSAGE      = "ATTT PTIT"
START_BIN    = 100
INPUT_WAV    = "input.wav"
OUTPUT_WAV   = "stego.wav"

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def phase_embed(audio, message, segment_size, start_bin):
    bits      = str_to_bits(message)
    segment   = audio[:segment_size].astype(np.float64)
    fft_data  = np.fft.fft(segment)
    magnitude = np.abs(fft_data)
    phase     = np.angle(fft_data)
    for i, bit in enumerate(bits):
        k = start_bin + i
        phase[k]             = np.pi/2 if bit == 1 else -np.pi/2
        phase[segment_size-k] = -phase[k]
    modified_fft     = magnitude * np.exp(1j * phase)
    modified_segment = np.real(np.fft.ifft(modified_fft))
    result = audio.copy().astype(np.float64)
    result[:segment_size] = modified_segment
    return result

print("=== Phase Coding Embed ===")
rate, audio = wavfile.read(INPUT_WAV)
audio = audio.astype(np.float32)
print("[*] Doc audio: {}".format(INPUT_WAV))
print("[*] Sample rate: {} Hz, Samples: {}".format(rate, len(audio)))
print("[*] Nhung message: '{}' ({} bits)".format(MESSAGE, len(MESSAGE)*8))
stego = phase_embed(audio, MESSAGE, SEGMENT_SIZE, START_BIN)
stego = np.clip(stego, -32768, 32767).astype(np.int16)
wavfile.write(OUTPUT_WAV, rate, stego)
signal_power = np.mean(audio.astype(np.float64)**2)
noise_power  = np.mean((audio.astype(np.float64) - stego.astype(np.float64))**2)
snr = 10*np.log10(signal_power/noise_power) if noise_power > 1e-10 else 999
print("[OK] Stego audio: {}".format(OUTPUT_WAV))
print("[*] SNR: {:.2f} dB".format(snr))
