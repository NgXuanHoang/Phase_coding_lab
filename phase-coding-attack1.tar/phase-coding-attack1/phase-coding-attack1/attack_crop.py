#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile
import sys

INPUT_WAV    = "stego.wav"
OUTPUT_WAV   = "cropped.wav"
SEGMENT_SIZE = 8192
CROP_PCT     = float(sys.argv[1]) if len(sys.argv) > 1 else 30.0
CROP_FROM    = sys.argv[2] if len(sys.argv) > 2 else "start"

print("=== Cropping Attack ({}% from {}) ===".format(CROP_PCT, CROP_FROM))
rate, audio = wavfile.read(INPUT_WAV)
cut = int(len(audio) * CROP_PCT / 100)
cut = (cut // SEGMENT_SIZE) * SEGMENT_SIZE
if CROP_FROM == "start":
    cropped = audio[cut:]
    print("[!] Cat tu DAU - segment chua tin bi mat!")
else:
    cropped = audio[:len(audio)-cut]
    print("[*] Cat tu CUOI - segment chua tin van con")
wavfile.write(OUTPUT_WAV, rate, cropped)
print("[*] Goc    : {} samples".format(len(audio)))
print("[*] Con lai: {} samples".format(len(cropped)))
print("[OK] Cropped: {}".format(OUTPUT_WAV))
