#!/bin/bash
pip3 install numpy scipy --break-system-packages 2>/dev/null || true
