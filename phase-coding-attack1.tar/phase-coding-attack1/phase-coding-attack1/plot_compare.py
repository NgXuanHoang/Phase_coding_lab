#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
import subprocess

files = {
    "1. Audio Goc (input.wav)":         "input.wav",
    "2. Sau Giau Tin (stego.wav)":       "stego.wav",
    "3. Sau Tan Cong Nhieu (noisy.wav)": "noisy.wav",
    "4. Sau Cat Audio (cropped.wav)":    "cropped.wav",
}

available = {k: v for k, v in files.items() if os.path.exists(v)}
n = len(available)

if n == 0:
    print("Khong co file wav nao! Hay chay embed.py truoc.")
    exit(1)

fig, axes = plt.subplots(n, 2, figsize=(14, 3*n))
fig.suptitle("So Sanh Waveform va Pho Tan So", fontsize=14, fontweight='bold')

if n == 1:
    axes = [axes]

for idx, (label, fname) in enumerate(available.items()):
    rate, audio = wavfile.read(fname)
    audio = audio.astype(np.float32)
    t = np.linspace(0, len(audio)/rate, len(audio))

    # Waveform
    axes[idx][0].plot(t[:5000], audio[:5000], color='steelblue', linewidth=0.5)
    axes[idx][0].set_title(label, fontsize=9, fontweight='bold')
    axes[idx][0].set_xlabel("Thoi gian (s)")
    axes[idx][0].set_ylabel("Bien do")
    axes[idx][0].grid(True, alpha=0.3)

    # Spectrum
    fft = np.abs(np.fft.rfft(audio[:8192]))
    freqs = np.fft.rfftfreq(8192, 1/rate)
    axes[idx][1].plot(freqs, 20*np.log10(fft + 1e-10), color='tomato', linewidth=0.5)
    axes[idx][1].set_title("Pho tan so - " + fname, fontsize=9)
    axes[idx][1].set_xlabel("Tan so (Hz)")
    axes[idx][1].set_ylabel("dB")
    axes[idx][1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig("waveform_compare.png", dpi=150, bbox_inches='tight')
print("[OK] Da luu: waveform_compare.png")

# Mo anh bang eog (Eye of GNOME) nhu bai mau
subprocess.Popen(['eog', 'waveform_compare.png'])
print("[OK] Da mo anh waveform_compare.png")
