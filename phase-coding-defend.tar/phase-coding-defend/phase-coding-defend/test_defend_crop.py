#!/usr/bin/env python3
"""
test_defend_crop.py - CW5: So sanh BER co/khong phong thu voi Cropping
CW5: DEFEND_CROP=SUCCESS

Su dung: python3 test_defend_crop.py
"""
import numpy as np
from scipy.io import wavfile

SEGMENT_SIZE = 8192
MESSAGE      = "LABTAINER"
START_BIN    = 100
N_SPREAD     = 3
CROP_PCT     = 30.0   # % cat tu DAU

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def bits_to_str(bits):
    chars = []
    for i in range(0, len(bits) - 7, 8):
        byte = int(''.join(str(b) for b in bits[i:i+8]), 2)
        chars.append(chr(byte))
    return ''.join(chars)

def crop_from_start(audio, crop_pct, segment_size):
    cut = int(len(audio) * crop_pct / 100)
    cut = (cut // segment_size) * segment_size
    return audio[cut:]

def phase_extract_basic(audio, num_chars, segment_size, start_bin):
    num_bits = num_chars * 8
    if len(audio) < segment_size:
        return [0] * num_bits
    segment  = audio[:segment_size].astype(np.float64)
    fft_data = np.fft.fft(segment)
    phase    = np.angle(fft_data)
    bits = []
    for i in range(num_bits):
        k = start_bin + i
        bits.append(1 if phase[k] >= 0 else 0)
    return bits

def spread_extract(audio, num_chars, segment_size, start_bin, n_spread):
    """
    Spread Extract sau khi cat: thu tim lai bit tu cac segment con lai
    Vi moi bit co N ban sao, du mat mot so van khoi phuc duoc
    """
    num_bits = num_chars * 8
    bits     = []

    for bit_idx in range(num_bits):
        votes = []
        for rep in range(n_spread):
            seg_idx = bit_idx * n_spread + rep
            offset  = seg_idx * segment_size
            if offset + segment_size > len(audio):
                # Segment bi mat do cat
                continue
            segment  = audio[offset:offset+segment_size].astype(np.float64)
            fft_data = np.fft.fft(segment)
            phase    = np.angle(fft_data)
            votes.append(1 if phase[start_bin] >= 0 else 0)

        if len(votes) == 0:
            bits.append(0)
        else:
            bit = 1 if sum(votes) > len(votes) / 2 else 0
            bits.append(bit)

    return bits

def spread_extract_with_sync(audio, num_chars, segment_size, start_bin, n_spread):
    """
    Spread + Sync: tim sync marker truoc, roi doc tu do
    Don gian hoa: just try extracting from where audio starts
    """
    return spread_extract(audio, num_chars, segment_size, start_bin, n_spread)

def compute_ber(orig, recv):
    errors = sum(o != r for o, r in zip(orig, recv))
    return errors / len(orig)

# ============================================================
print("=== test_defend_crop.py: Phong Thu vs Cropping ===")
print("[*] Crop: {}% tu DAU file".format(CROP_PCT))
print("[*] N_SPREAD: {}".format(N_SPREAD))

orig_bits = str_to_bits(MESSAGE)

# --- Doc stego ---
rate, stego_spread = wavfile.read("stego_spread.wav")
stego_spread = stego_spread.astype(np.float32)

rate, stego_basic = wavfile.read("stego_basic.wav")
stego_basic = stego_basic.astype(np.float32)

# --- Tan cong Cropping tu DAU ---
cropped_spread = crop_from_start(stego_spread.astype(np.int16), CROP_PCT, SEGMENT_SIZE)
cropped_basic  = crop_from_start(stego_basic.astype(np.int16),  CROP_PCT, SEGMENT_SIZE)

print("[*] Goc   : {} samples".format(len(stego_basic)))
print("[*] Con lai: {} samples (cat {}%)".format(len(cropped_basic), CROP_PCT))

# --- Do BER ---
recv_basic  = phase_extract_basic(cropped_basic.astype(np.float32),
                                   len(MESSAGE), SEGMENT_SIZE, START_BIN)
ber_basic   = compute_ber(orig_bits, recv_basic)

recv_spread = spread_extract_with_sync(cropped_spread.astype(np.float32),
                                        len(MESSAGE), SEGMENT_SIZE, START_BIN, N_SPREAD)
ber_spread  = compute_ber(orig_bits, recv_spread)

improve = (ber_basic - ber_spread) / ber_basic * 100 if ber_basic > 0 else 0

print("")
print("┌─────────────────────────────────────────────┐")
print("│   KET QUA: Cropping {}% tu DAU             │".format(CROP_PCT))
print("├───────────────────────┬─────────────────────┤")
print("│ Khong phong thu       │ BER = {:.4f} ({:.1f}%) │".format(ber_basic, ber_basic*100))
print("│ Co Spread Embedding   │ BER = {:.4f} ({:.1f}%) │".format(ber_spread, ber_spread*100))
print("│ Cai thien             │ {:.1f}%               │".format(improve))
print("└───────────────────────┴─────────────────────┘")
print("")
print("[*] Extract khong phong thu: '{}'".format(bits_to_str(recv_basic)))
print("[*] Extract co phong thu  : '{}'".format(bits_to_str(recv_spread)))
print("BER_NO_DEFEND_CROP={:.6f}".format(ber_basic))
print("BER_SPREAD_CROP={:.6f}".format(ber_spread))

if ber_spread <= ber_basic:
    print("DEFEND_CROP=SUCCESS")
    print("[OK] Spread Embedding GIAM BER truoc tan cong Cropping!")
else:
    print("DEFEND_CROP=FAILED")
    print("[!] Spread Embedding khong cai thien BER voi Cropping")
