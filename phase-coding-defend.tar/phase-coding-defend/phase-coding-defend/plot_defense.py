#!/usr/bin/env python3
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
import subprocess

def read_ber(fname):
    if not os.path.exists(fname): return None
    with open(fname) as f:
        for line in f:
            if line.startswith("BER="):
                return float(line.split("=")[1])
    return None

# BER khong phong thu (tu Lab 1 & 2)
no_defense = {
    "Noise\nSNR=10dB": read_ber("ber_noise_lab1.txt"),
    "Cropping\n30%":    read_ber("ber_crop_lab1.txt"),
    "MP3\n128kbps":     read_ber("ber_mp3_lab2.txt"),
}

# BER co phong thu
with_defense = {
    "Noise\nSNR=10dB": read_ber("ber_defended_noise.txt"),
    "Cropping\n30%":    read_ber("ber_defended_crop.txt"),
    "MP3\n128kbps":     read_ber("ber_defended_mp3.txt"),
}

labels   = list(no_defense.keys())
no_def_v = [no_defense[k] or 0 for k in labels]
wi_def_v = [with_defense[k] or 0 for k in labels]

x   = range(len(labels))
fig, ax = plt.subplots(figsize=(10, 6))
w   = 0.35
b1  = ax.bar([i-w/2 for i in x], no_def_v, w,
             label='Khong phong thu', color='#e74c3c', edgecolor='black')
b2  = ax.bar([i+w/2 for i in x], wi_def_v, w,
             label='Co phong thu', color='#2ecc71', edgecolor='black')

ax.set_ylabel("BER", fontsize=12)
ax.set_title("So sanh BER Truoc/Sau Phong Thu\nKey=42, Spread N=3, Sync Marker Barker-7",
             fontsize=12, fontweight='bold')
ax.set_xticks(list(x))
ax.set_xticklabels(labels, fontsize=11)
ax.set_ylim(0, 1.0)
ax.axhline(0.5, color='red', linestyle='--', linewidth=1, alpha=0.5,
           label='BER=0.5 (mat hoan toan)')
ax.legend(fontsize=10)
ax.grid(True, axis='y', alpha=0.3)

for bar in b1:
    h = bar.get_height()
    ax.text(bar.get_x()+bar.get_width()/2, h+0.01,
            "{:.3f}".format(h), ha='center', fontsize=9, fontweight='bold')
for bar in b2:
    h = bar.get_height()
    if h > 0:
        ax.text(bar.get_x()+bar.get_width()/2, h+0.01,
                "{:.3f}".format(h), ha='center', fontsize=9, fontweight='bold')

plt.tight_layout()
plt.savefig("defense_comparison.png", dpi=150, bbox_inches='tight')
print("[OK] Da luu: defense_comparison.png")
subprocess.Popen(['eog', 'defense_comparison.png'])
