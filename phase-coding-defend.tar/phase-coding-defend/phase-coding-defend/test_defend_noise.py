#!/usr/bin/env python3
"""
test_defend_noise.py - CW4: So sanh BER co/khong phong thu voi Gaussian Noise
CW4: DEFEND_NOISE=SUCCESS

Su dung: python3 test_defend_noise.py
"""
import numpy as np
from scipy.io import wavfile

SEGMENT_SIZE = 8192
MESSAGE      = "LABTAINER"
START_BIN    = 100
N_SPREAD     = 3
TARGET_SNR   = -5.0   # dB - tan cong manh

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def bits_to_str(bits):
    chars = []
    for i in range(0, len(bits) - 7, 8):
        byte = int(''.join(str(b) for b in bits[i:i+8]), 2)
        chars.append(chr(byte))
    return ''.join(chars)

def add_gaussian_noise(audio, target_snr_db):
    audio_f      = audio.astype(np.float64)
    signal_power = np.mean(audio_f**2)
    snr_linear   = 10 ** (target_snr_db / 10)
    noise_std    = np.sqrt(signal_power / snr_linear)
    noise        = np.random.normal(0, noise_std, audio_f.shape)
    noisy        = np.clip(audio_f + noise, -32768, 32767)
    return noisy.astype(np.int16)

def phase_extract_basic(audio, num_chars, segment_size, start_bin):
    num_bits = num_chars * 8
    segment  = audio[:segment_size].astype(np.float64)
    fft_data = np.fft.fft(segment)
    phase    = np.angle(fft_data)
    bits = []
    for i in range(num_bits):
        k = start_bin + i
        bits.append(1 if phase[k] >= 0 else 0)
    return bits

def spread_extract(audio, num_chars, segment_size, start_bin, n_spread):
    num_bits = num_chars * 8
    bits     = []
    for bit_idx in range(num_bits):
        votes = []
        for rep in range(n_spread):
            seg_idx = bit_idx * n_spread + rep
            offset  = seg_idx * segment_size
            if offset + segment_size > len(audio):
                votes.append(0)
                continue
            segment  = audio[offset:offset+segment_size].astype(np.float64)
            fft_data = np.fft.fft(segment)
            phase    = np.angle(fft_data)
            votes.append(1 if phase[start_bin] >= 0 else 0)
        bit = 1 if sum(votes) > n_spread / 2 else 0
        bits.append(bit)
    return bits

def compute_ber(orig, recv):
    errors = sum(o != r for o, r in zip(orig, recv))
    return errors / len(orig)

# ============================================================
print("=== test_defend_noise.py: Phong Thu vs Gaussian Noise ===")
print("[*] SNR tan cong: {} dB".format(TARGET_SNR))
print("[*] N_SPREAD    : {}".format(N_SPREAD))

orig_bits = str_to_bits(MESSAGE)

# --- Doc stego co phong thu ---
rate, stego_spread = wavfile.read("stego_spread.wav")
stego_spread = stego_spread.astype(np.float32)

# --- Doc stego khong phong thu ---
rate, stego_basic = wavfile.read("stego_basic.wav")
stego_basic = stego_basic.astype(np.float32)

# --- Tan cong ca hai ---
np.random.seed(42)
noisy_spread = add_gaussian_noise(stego_spread.astype(np.int16), TARGET_SNR)
np.random.seed(42)
noisy_basic  = add_gaussian_noise(stego_basic.astype(np.int16), TARGET_SNR)

# --- Do BER ---
# Khong phong thu
recv_basic = phase_extract_basic(noisy_basic.astype(np.float32),
                                  len(MESSAGE), SEGMENT_SIZE, START_BIN)
ber_basic  = compute_ber(orig_bits, recv_basic)

# Co phong thu (Spread Embedding)
recv_spread = spread_extract(noisy_spread.astype(np.float32),
                              len(MESSAGE), SEGMENT_SIZE, START_BIN, N_SPREAD)
ber_spread  = compute_ber(orig_bits, recv_spread)

# --- Ket qua ---
improve = (ber_basic - ber_spread) / ber_basic * 100 if ber_basic > 0 else 0

print("")
print("┌─────────────────────────────────────────────┐")
print("│   KET QUA: Gaussian Noise SNR={} dB       │".format(TARGET_SNR))
print("├───────────────────────┬─────────────────────┤")
print("│ Khong phong thu       │ BER = {:.4f} ({:.1f}%) │".format(ber_basic, ber_basic*100))
print("│ Co Spread Embedding   │ BER = {:.4f} ({:.1f}%) │".format(ber_spread, ber_spread*100))
print("│ Cai thien             │ {:.1f}%               │".format(improve))
print("└───────────────────────┴─────────────────────┘")
print("")
print("[*] Extract khong phong thu: '{}'".format(bits_to_str(recv_basic)))
print("[*] Extract co phong thu  : '{}'".format(bits_to_str(recv_spread)))
print("BER_NO_DEFEND_NOISE={:.6f}".format(ber_basic))
print("BER_SPREAD_NOISE={:.6f}".format(ber_spread))

if ber_spread <= ber_basic:
    print("DEFEND_NOISE=SUCCESS")
    print("[OK] Spread Embedding GIAM BER truoc tan cong Noise!")
else:
    print("DEFEND_NOISE=FAILED")
    print("[!] Spread Embedding khong cai thien BER")
