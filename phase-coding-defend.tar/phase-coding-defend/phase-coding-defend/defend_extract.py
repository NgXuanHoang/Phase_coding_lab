#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile
import sys

SEGMENT_SIZE = 8192
START_BIN    = 100
N_COPIES     = 3
MESSAGE      = "ATTT PTIT"
KEY          = 42
INPUT_WAV    = sys.argv[1] if len(sys.argv) > 1 else "stego_defended.wav"

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def bits_to_str(bits):
    chars = []
    for i in range(0, len(bits)-7, 8):
        byte = int(''.join(str(b) for b in bits[i:i+8]), 2)
        chars.append(chr(byte))
    return ''.join(chars)

def get_bit(audio, seg_idx, bin_idx):
    s = seg_idx * SEGMENT_SIZE
    e = s + SEGMENT_SIZE
    if e > len(audio): return 0
    seg = audio[s:e].astype(np.float64)
    pha = np.angle(np.fft.fft(seg))
    return 1 if float(pha[bin_idx]) >= 0 else 0

rate, audio = wavfile.read(INPUT_WAV)
if audio.ndim > 1:
    audio = audio.mean(axis=1).astype(np.int16)

bits         = str_to_bits(MESSAGE)
num_bits     = len(bits)
max_segments = len(audio) // SEGMENT_SIZE

# Cung logic segment nhu defend_embed.py
segments_per_copy = []
for copy_idx in range(N_COPIES):
    offset = copy_idx * num_bits
    segs = [(offset + bit_idx) % max_segments for bit_idx in range(num_bits)]
    segments_per_copy.append(segs)

# Trich xuat N_COPIES ban sao
copies = []
for copy_idx in range(N_COPIES):
    copy_bits = []
    for bit_idx in range(num_bits):
        seg_idx = segments_per_copy[copy_idx][bit_idx]
        copy_bits.append(get_bit(audio, seg_idx, START_BIN))
    copies.append(copy_bits)

# Majority Vote
final_bits = []
for i in range(num_bits):
    votes = [copies[c][i] for c in range(N_COPIES)]
    final_bits.append(1 if sum(votes) > N_COPIES//2 else 0)

msg = bits_to_str(final_bits)
print("Extracted: '{}'".format(msg))
print("Bits: {}".format(''.join(str(b) for b in final_bits)))
