#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile
import sys

INPUT_WAV  = sys.argv[1] if len(sys.argv) > 1 else "stego_defended.wav"
OUTPUT_WAV = sys.argv[2] if len(sys.argv) > 2 else "noisy_defended.wav"
TARGET_SNR = float(sys.argv[3]) if len(sys.argv) > 3 else 10.0

print("=== Gaussian Noise Attack (SNR={}dB) ===".format(TARGET_SNR))
rate, audio = wavfile.read(INPUT_WAV)
audio = audio.astype(np.float64)
signal_power = np.mean(audio**2)
snr_linear   = 10 ** (TARGET_SNR / 10)
noise_std    = np.sqrt(signal_power / snr_linear)
noise        = np.random.normal(0, noise_std, audio.shape)
noisy        = np.clip(audio + noise, -32768, 32767).astype(np.int16)
wavfile.write(OUTPUT_WAV, rate, noisy)
print("[OK] Noisy defended: {}".format(OUTPUT_WAV))
