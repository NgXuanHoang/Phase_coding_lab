#!/bin/bash
#
#  This script will be run after parameterization has completed.
#  The container user password will be passed as the first argument.
#
