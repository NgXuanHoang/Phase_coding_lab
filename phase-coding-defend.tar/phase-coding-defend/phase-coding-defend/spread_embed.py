#!/usr/bin/env python3
"""
spread_embed.py - Phong thu bang Spread Embedding (nhung moi bit N lan)
CW1: BER_BASELINE=0.000000
CW2: SPREAD_EMBED=SUCCESS

Su dung: python3 spread_embed.py
"""
import numpy as np
from scipy.io import wavfile

SEGMENT_SIZE = 8192
MESSAGE      = "LABTAINER"
START_BIN    = 100
N_SPREAD     = 3       # Moi bit duoc nhung vao N segment
INPUT_WAV    = "input.wav"
OUTPUT_WAV   = "stego_spread.wav"

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def bits_to_str(bits):
    chars = []
    for i in range(0, len(bits) - 7, 8):
        byte = int(''.join(str(b) for b in bits[i:i+8]), 2)
        chars.append(chr(byte))
    return ''.join(chars)

def phase_embed_segment(audio_chunk, bit, start_bin, segment_size):
    """Nhung 1 bit vao 1 segment"""
    segment   = audio_chunk[:segment_size].astype(np.float64)
    fft_data  = np.fft.fft(segment)
    magnitude = np.abs(fft_data)
    phase     = np.angle(fft_data)
    k = start_bin
    phase[k]              = np.pi/2 if bit == 1 else -np.pi/2
    phase[segment_size-k] = -phase[k]
    modified_fft     = magnitude * np.exp(1j * phase)
    modified_segment = np.real(np.fft.ifft(modified_fft))
    result = audio_chunk.copy().astype(np.float64)
    result[:segment_size] = modified_segment
    return result

def spread_embed(audio, message, segment_size, start_bin, n_spread):
    """
    Spread Embedding: nhung moi bit vao N segment lien tiep
    segment 0,1,...,n_spread-1 -> bit 0
    segment n_spread,...,2*n_spread-1 -> bit 1
    ...
    """
    bits        = str_to_bits(message)
    num_bits    = len(bits)
    num_segs    = num_bits * n_spread
    result      = audio.copy().astype(np.float32)

    for bit_idx, bit in enumerate(bits):
        for rep in range(n_spread):
            seg_idx  = bit_idx * n_spread + rep
            offset   = seg_idx * segment_size
            if offset + segment_size > len(audio):
                break
            chunk = result[offset:offset+segment_size].copy()
            modified = phase_embed_segment(chunk, bit, start_bin, segment_size)
            result[offset:offset+segment_size] = modified.astype(np.float32)

    return result

def spread_extract(audio, num_chars, segment_size, start_bin, n_spread):
    """
    Giai ma Spread Embedding bang majority voting
    Doc N segment cho moi bit, lay ket qua da so
    """
    num_bits = num_chars * 8
    bits     = []

    for bit_idx in range(num_bits):
        votes = []
        for rep in range(n_spread):
            seg_idx = bit_idx * n_spread + rep
            offset  = seg_idx * segment_size
            if offset + segment_size > len(audio):
                votes.append(0)
                continue
            segment  = audio[offset:offset+segment_size].astype(np.float64)
            fft_data = np.fft.fft(segment)
            phase    = np.angle(fft_data)
            votes.append(1 if phase[start_bin] >= 0 else 0)

        # Majority voting
        bit = 1 if sum(votes) > n_spread / 2 else 0
        bits.append(bit)

    return bits

def compute_ber(orig_bits, recv_bits):
    errors = sum(o != r for o, r in zip(orig_bits, recv_bits))
    return errors / len(orig_bits)

# ============================================================
print("=== spread_embed.py: Spread Embedding (N={}) ===".format(N_SPREAD))
rate, audio = wavfile.read(INPUT_WAV)
audio = audio.astype(np.float32)

orig_bits = str_to_bits(MESSAGE)
num_bits  = len(orig_bits)

print("[*] Message : '{}' ({} bits)".format(MESSAGE, num_bits))
print("[*] N_SPREAD: {} (moi bit nhung {} lan)".format(N_SPREAD, N_SPREAD))
print("[*] Can {} segments = {} samples ({:.1f}s)".format(
    num_bits * N_SPREAD,
    num_bits * N_SPREAD * SEGMENT_SIZE,
    num_bits * N_SPREAD * SEGMENT_SIZE / rate))
print("[*] Audio dai: {} samples ({:.1f}s)".format(len(audio), len(audio)/rate))

if num_bits * N_SPREAD * SEGMENT_SIZE > len(audio):
    print("[ERROR] Audio qua ngan cho Spread Embedding!")
    exit(1)

# Nhung tin
stego = spread_embed(audio, MESSAGE, SEGMENT_SIZE, START_BIN, N_SPREAD)
stego_int = np.clip(stego, -32768, 32767).astype(np.int16)
wavfile.write(OUTPUT_WAV, rate, stego_int)

# Kiem tra BER baseline (chua tan cong)
recv_bits = spread_extract(stego.astype(np.float32), len(MESSAGE),
                           SEGMENT_SIZE, START_BIN, N_SPREAD)
ber = compute_ber(orig_bits, recv_bits)

print("[OK] Output : {}".format(OUTPUT_WAV))
print("[*] Extract : '{}'".format(bits_to_str(recv_bits)))
print("BER_BASELINE={:.6f}".format(ber))

if ber == 0.0:
    print("SPREAD_EMBED=SUCCESS")
    print("[OK] Spread Embedding thanh cong!")
    print("[*] Ghi chu: Capacity giam {}x (tu {} bit xuong {} bit max)".format(
        N_SPREAD, len(audio)//SEGMENT_SIZE, len(audio)//(SEGMENT_SIZE*N_SPREAD)))
else:
    print("SPREAD_EMBED=FAILED")
    print("[!] Loi: BER = {:.1f}%".format(ber*100))
