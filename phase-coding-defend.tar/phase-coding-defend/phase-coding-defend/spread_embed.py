#!/usr/bin/env python3
"""
CW2: Spread Embedding - nhung moi bit vao N=3 segment khac nhau
Robustness tang: can tan cong pha huy >= 2/3 ban sao moi mat tin
"""
import numpy as np
from scipy.io import wavfile
import sys

SEGMENT_SIZE = 8192
START_BIN    = 100
N_COPIES     = 3
MESSAGE      = "ATTT PTIT"
KEY          = 42
INPUT_WAV    = "input.wav"
OUTPUT_WAV   = "stego_spread.wav"

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def phase_embed_segment(audio, seg_idx, bits, start_bin):
    start = seg_idx * SEGMENT_SIZE
    end   = start + SEGMENT_SIZE
    if end > len(audio):
        return audio
    segment  = audio[start:end].astype(np.float64)
    fft_data = np.fft.fft(segment)
    magnitude= np.abs(fft_data)
    phase    = np.angle(fft_data)
    for i, bit in enumerate(bits):
        k = start_bin + i
        phase[k]              = np.pi/2 if bit==1 else -np.pi/2
        phase[SEGMENT_SIZE-k] = -phase[k]
    modified = magnitude * np.exp(1j * phase)
    result   = audio.copy()
    result[start:end] = np.clip(
        np.real(np.fft.ifft(modified)), -32768, 32767)
    return result

print("=== CW2: Spread Embedding (N={}) ===".format(N_COPIES))
rate, audio = wavfile.read(INPUT_WAV)
audio = audio.astype(np.float64)

bits         = str_to_bits(MESSAGE)
num_bits     = len(bits)
total_needed = num_bits * N_COPIES
max_segments = len(audio) // SEGMENT_SIZE

# Key-based segment selection
rng      = np.random.default_rng(seed=KEY)
selected = rng.choice(max_segments, size=total_needed, replace=True)
selected_sorted = sorted(selected.tolist())

# Nhung moi bit vao N=3 segment
# Bit i duoc nhung vao segment: selected[i], selected[i+num_bits], selected[i+2*num_bits]
for copy_idx in range(N_COPIES):
    for bit_idx, bit in enumerate(bits):
        seg_idx = selected_sorted[copy_idx * num_bits + bit_idx]
        audio   = phase_embed_segment(audio, seg_idx, [bit], START_BIN)

result = np.clip(audio, -32768, 32767).astype(np.int16)
wavfile.write(OUTPUT_WAV, rate, result)

orig_audio = wavfile.read(INPUT_WAV)[1].astype(np.float64)
snr = 10*np.log10(np.mean(orig_audio**2) /
      (np.mean((orig_audio - audio)**2) + 1e-10))

print("[*] Message   : '{}' ({} bits)".format(MESSAGE, num_bits))
print("[*] N copies  : {}".format(N_COPIES))
print("[*] Segments  : {} total".format(total_needed))
print("[*] Capacity  : {} bits (giam {}x so voi khong spread)".format(
      num_bits, N_COPIES))
print("[*] SNR       : {:.2f} dB".format(snr))
print("[OK] Spread embedding: {}".format(OUTPUT_WAV))
