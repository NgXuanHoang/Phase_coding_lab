#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile

SEGMENT_SIZE  = 8192
MARKER_BIN    = 200
MARKER_EVERY  = 10
BARKER7       = [1,1,1,0,0,1,0]
INPUT_WAV     = "stego_spread.wav"
OUTPUT_WAV    = "stego_sync.wav"

def read_mono(fname):
    rate, audio = wavfile.read(fname)
    if audio.ndim > 1:
        audio = audio.mean(axis=1).astype(np.int16)
    return rate, audio

def set_bit(audio, seg_idx, bin_idx, bit):
    s = seg_idx * SEGMENT_SIZE
    e = s + SEGMENT_SIZE
    if e > len(audio): return audio
    seg = audio[s:e].astype(np.float64)
    fft = np.fft.fft(seg)
    mag = np.abs(fft)
    pha = np.angle(fft)
    pha[bin_idx]              = np.pi/2 if bit==1 else -np.pi/2
    pha[SEGMENT_SIZE-bin_idx] = -pha[bin_idx]
    out = audio.copy()
    out[s:e] = np.clip(
        np.real(np.fft.ifft(mag*np.exp(1j*pha))),
        -32768, 32767).astype(np.int16)
    return out

def detect_markers(audio):
    num_segments = len(audio) // SEGMENT_SIZE
    found = []
    for seg_idx in range(num_segments):
        s   = seg_idx * SEGMENT_SIZE
        seg = audio[s:s+SEGMENT_SIZE].astype(np.float64)
        pha = np.angle(np.fft.fft(seg))
        detected = [1 if float(pha[MARKER_BIN+i])>=0 else 0
                    for i in range(len(BARKER7))]
        if detected == BARKER7:
            found.append(seg_idx)
    return found

print("=== CW3: Sync Marker (Barker-7) ===")
rate, audio = read_mono(INPUT_WAV)

num_segments = len(audio) // SEGMENT_SIZE
marker_segs  = list(range(0, num_segments, MARKER_EVERY))

print("[*] Barker-7  : {}".format(BARKER7))
print("[*] Chen marker moi {} segment".format(MARKER_EVERY))
print("[*] So marker : {}".format(len(marker_segs)))

for seg_idx in marker_segs:
    for i, val in enumerate(BARKER7):
        audio = set_bit(audio, seg_idx, MARKER_BIN+i, val)

result = audio.copy()
wavfile.write(OUTPUT_WAV, rate, result)

found = detect_markers(result)
print("[*] Da chen   : {} markers".format(len(marker_segs)))
print("[*] Tim thay  : {} markers".format(len(found)))
print("[*] Vi tri    : {}".format(found[:5]))

if len(found) >= 3:
    print("[OK] Sync marker: {} markers detected".format(len(found)))
else:
    print("[-] Canh bao: Chi tim thay {} markers!".format(len(found)))
