#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile
import sys

INPUT_WAV    = sys.argv[1] if len(sys.argv) > 1 else "stego_defended.wav"
OUTPUT_WAV   = sys.argv[2] if len(sys.argv) > 2 else "cropped_defended.wav"
SEGMENT_SIZE = 8192
CROP_PCT     = float(sys.argv[3]) if len(sys.argv) > 3 else 30.0

print("=== Cropping Attack ({}%) ===".format(CROP_PCT))
rate, audio = wavfile.read(INPUT_WAV)
cut = int(len(audio) * CROP_PCT / 100)
cut = (cut // SEGMENT_SIZE) * SEGMENT_SIZE
cropped = audio[cut:]
wavfile.write(OUTPUT_WAV, rate, cropped)
print("[*] Goc    : {} samples".format(len(audio)))
print("[*] Con lai: {} samples".format(len(cropped)))
print("[OK] Cropped defended: {}".format(OUTPUT_WAV))
