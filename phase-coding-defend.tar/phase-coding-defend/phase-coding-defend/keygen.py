#!/usr/bin/env python3
"""
CW1: Key-based Segment Selection
Dung key -> PRNG -> chon ngau nhien cac segment de nhung tin
"""
import numpy as np
import sys

SEGMENT_SIZE  = 8192
RATE          = 44100
AUDIO_SAMPLES = 831744
N_COPIES      = 3
MESSAGE       = "ATTT PTIT"
KEY           = int(sys.argv[1]) if len(sys.argv) > 1 else 42

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

num_bits     = len(str_to_bits(MESSAGE))
total_needed = num_bits * N_COPIES
max_segments = AUDIO_SAMPLES // SEGMENT_SIZE

print("=== CW1: Key-based Segment Selection ===")
print("[*] Key       : {}".format(KEY))
print("[*] Message   : '{}' ({} bits)".format(MESSAGE, num_bits))
print("[*] Spread N  : {}".format(N_COPIES))
print("[*] Can chon  : {} segment".format(total_needed))
print("[*] Tong co   : {} segment".format(max_segments))

# Dung key lam seed cho PRNG
rng = np.random.default_rng(seed=KEY)
# replace=True vi total_needed > max_segments
selected = rng.choice(max_segments, size=total_needed, replace=True)
selected_sorted = sorted(selected.tolist())

# Luu vao file
with open("segments.txt", "w") as f:
    f.write("KEY={}\n".format(KEY))
    f.write("N_COPIES={}\n".format(N_COPIES))
    f.write("NUM_BITS={}\n".format(num_bits))
    f.write("TOTAL_SEGMENTS={}\n".format(total_needed))
    f.write("SEGMENTS={}\n".format(",".join(map(str, selected_sorted))))

print("[*] Segment dau tien: {}".format(selected_sorted[:5]))
print("[*] Segment cuoi    : {}".format(selected_sorted[-5:]))
print("[*] Ghi chu: Co the co segment trung lap (replace=True)")
print("[OK] Key-based selection: {} segments chon".format(total_needed))
