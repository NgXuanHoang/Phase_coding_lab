#!/usr/bin/env python3
import subprocess
import sys
import os
from scipy.io import wavfile

INPUT_WAV = sys.argv[1] if len(sys.argv) > 1 else "stego_defended.wav"
BITRATE   = sys.argv[2] if len(sys.argv) > 2 else "128"
MP3_FILE  = "temp_defended.mp3"
OUT_WAV   = sys.argv[3] if len(sys.argv) > 3 else "mp3_defended.wav"

print("=== MP3 Compression Attack ({}kbps) ===".format(BITRATE))
subprocess.run(["ffmpeg","-y","-i",INPUT_WAV,"-b:a","{}k".format(BITRATE),
    "-codec:a","libmp3lame",MP3_FILE], capture_output=True)
subprocess.run(["ffmpeg","-y","-i",MP3_FILE,OUT_WAV], capture_output=True)
os.remove(MP3_FILE)
print("[OK] MP3 defended {}kbps: {}".format(BITRATE, OUT_WAV))
