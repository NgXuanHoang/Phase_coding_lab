#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile

SEGMENT_SIZE = 8192
START_BIN    = 100
MARKER_BIN   = 200
N_COPIES     = 3
MARKER_EVERY = 10
BARKER7      = [1,1,1,0,0,1,0]
MESSAGE      = "ATTT PTIT"
KEY          = 42
INPUT_WAV    = "input.wav"
OUTPUT_WAV   = "stego_defended.wav"

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def read_mono(fname):
    rate, audio = wavfile.read(fname)
    if audio.ndim > 1:
        audio = audio.mean(axis=1).astype(np.int16)
    return rate, audio

def set_bit(audio, seg_idx, bin_idx, bit):
    s = seg_idx * SEGMENT_SIZE
    e = s + SEGMENT_SIZE
    if e > len(audio): return audio
    seg = audio[s:e].astype(np.float64)
    fft = np.fft.fft(seg)
    mag = np.abs(fft)
    pha = np.angle(fft)
    pha[bin_idx]              = np.pi/2 if bit==1 else -np.pi/2
    pha[SEGMENT_SIZE-bin_idx] = -pha[bin_idx]
    out = audio.copy()
    out[s:e] = np.clip(
        np.real(np.fft.ifft(mag*np.exp(1j*pha))),
        -32768, 32767).astype(np.int16)
    return out

def get_bit(audio, seg_idx, bin_idx):
    s = seg_idx * SEGMENT_SIZE
    e = s + SEGMENT_SIZE
    if e > len(audio): return 0
    seg = audio[s:e].astype(np.float64)
    pha = np.angle(np.fft.fft(seg))
    return 1 if float(pha[bin_idx]) >= 0 else 0

print("=== CW4: Full Defense Pipeline ===")
rate, audio = read_mono(INPUT_WAV)

bits         = str_to_bits(MESSAGE)
num_bits     = len(bits)
max_segments = len(audio) // SEGMENT_SIZE

# Buoc 1: Key-based selection
# Moi bit i duoc nhung vao 3 segment RIENG BIET, khong trung nhau
rng = np.random.default_rng(seed=KEY)
# Tao pool segment cho moi copy
segments_per_copy = []
for copy_idx in range(N_COPIES):
    # Dung offset khac nhau de tranh trung lap giua cac copy
    offset = copy_idx * num_bits
    segs = [(offset + bit_idx) % max_segments for bit_idx in range(num_bits)]
    segments_per_copy.append(segs)

print("[*] Buoc 1: Key={}, {} segments/copy".format(KEY, num_bits))

# Buoc 2: Spread Embedding - dam bao khong ghi de
for copy_idx in range(N_COPIES):
    for bit_idx, bit in enumerate(bits):
        seg_idx = segments_per_copy[copy_idx][bit_idx]
        audio   = set_bit(audio, seg_idx, START_BIN, bit)
print("[*] Buoc 2: Moi bit nhung {} lan".format(N_COPIES))

# Buoc 3: Sync Marker
marker_segs = list(range(0, max_segments, MARKER_EVERY))
for seg_idx in marker_segs:
    for i, val in enumerate(BARKER7):
        audio = set_bit(audio, seg_idx, MARKER_BIN+i, val)
print("[*] Buoc 3: {} sync markers".format(len(marker_segs)))

wavfile.write(OUTPUT_WAV, rate, audio)

# Verify
errors = 0
for copy_idx in range(N_COPIES):
    for bit_idx, bit in enumerate(bits):
        seg_idx = segments_per_copy[copy_idx][bit_idx]
        got = get_bit(audio, seg_idx, START_BIN)
        if got != bit: errors += 1

orig = read_mono(INPUT_WAV)[1].astype(np.float64)
snr  = 10*np.log10(np.mean(orig**2)/
       (np.mean((orig-audio.astype(np.float64))**2)+1e-10))
print("[*] SNR: {:.2f} dB".format(snr))
print("[*] Verify errors: {}/{}".format(errors, N_COPIES*num_bits))
print("[OK] Pipeline BER: {:.4f}".format(errors/(N_COPIES*num_bits)))
print("[OK] Full pipeline: {}".format(OUTPUT_WAV))
