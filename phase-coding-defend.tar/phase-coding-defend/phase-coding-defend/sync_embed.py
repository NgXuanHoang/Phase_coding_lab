#!/usr/bin/env python3
"""
sync_embed.py - Phong thu bang Sync Marker (Barker-7 sequence)
CW3: SYNC_MARKER=FOUND

Su dung: python3 sync_embed.py
"""
import numpy as np
from scipy.io import wavfile

SEGMENT_SIZE  = 8192
MESSAGE       = "LABTAINER"
START_BIN     = 100
MARKER_BIN    = 50       # Tan so rieng cho sync marker
MARKER_EVERY  = 5        # Chen marker moi 5 segment
INPUT_WAV     = "stego_spread.wav"  # Dung stego tu spread_embed
OUTPUT_WAV    = "stego_sync.wav"

# Barker-7 sequence: [-1,1,-1,-1,1,1,1] -> [0,1,0,0,1,1,1]
BARKER7 = [0, 1, 0, 0, 1, 1, 1]

def embed_marker_in_segment(audio_chunk, segment_size, marker_bin):
    """Nhung Barker-7 marker vao segment tai marker_bin"""
    segment   = audio_chunk[:segment_size].astype(np.float64)
    fft_data  = np.fft.fft(segment)
    magnitude = np.abs(fft_data)
    phase     = np.angle(fft_data)

    for i, bit in enumerate(BARKER7):
        k = marker_bin + i
        phase[k]              = np.pi/2 if bit == 1 else -np.pi/2
        phase[segment_size-k] = -phase[k]

    modified_fft     = magnitude * np.exp(1j * phase)
    modified_segment = np.real(np.fft.ifft(modified_fft))
    result = audio_chunk.copy().astype(np.float64)
    result[:segment_size] = modified_segment
    return result

def detect_marker_in_segment(audio_chunk, segment_size, marker_bin):
    """Doc Barker-7 tu segment va kiem tra co khop khong"""
    segment  = audio_chunk[:segment_size].astype(np.float64)
    fft_data = np.fft.fft(segment)
    phase    = np.angle(fft_data)
    detected = []
    for i in range(len(BARKER7)):
        k = marker_bin + i
        detected.append(1 if phase[k] >= 0 else 0)
    return detected == BARKER7

def embed_with_sync(audio, segment_size, marker_bin, marker_every):
    """Chen Barker-7 marker vao moi marker_every segment"""
    result   = audio.copy().astype(np.float32)
    num_segs = len(audio) // segment_size
    markers_added = 0

    for seg_idx in range(num_segs):
        if seg_idx % marker_every == 0:
            offset = seg_idx * segment_size
            chunk  = result[offset:offset+segment_size].copy()
            modified = embed_marker_in_segment(chunk, segment_size, marker_bin)
            result[offset:offset+segment_size] = modified.astype(np.float32)
            markers_added += 1

    return result, markers_added

def count_markers(audio, segment_size, marker_bin):
    """Dem so marker tim thay trong audio"""
    num_segs = len(audio) // segment_size
    count    = 0
    positions = []
    for seg_idx in range(num_segs):
        offset = seg_idx * segment_size
        chunk  = audio[offset:offset+segment_size]
        if detect_marker_in_segment(chunk, segment_size, marker_bin):
            count += 1
            positions.append(seg_idx)
    return count, positions

# ============================================================
print("=== sync_embed.py: Sync Marker (Barker-7) ===")
rate, audio = wavfile.read(INPUT_WAV)
audio = audio.astype(np.float32)

print("[*] Input : {}".format(INPUT_WAV))
print("[*] Barker-7 sequence: {}".format(BARKER7))
print("[*] Chen marker moi {} segment".format(MARKER_EVERY))

# Chen marker
stego, markers_added = embed_with_sync(audio, SEGMENT_SIZE, MARKER_BIN, MARKER_EVERY)
stego_int = np.clip(stego, -32768, 32767).astype(np.int16)
wavfile.write(OUTPUT_WAV, rate, stego_int)

print("[OK] Output: {}".format(OUTPUT_WAV))
print("[*] So marker da chen: {}".format(markers_added))

# Kiem tra lai
count, positions = count_markers(stego, SEGMENT_SIZE, MARKER_BIN)
print("[*] So marker tim thay: {}".format(count))
print("[*] Vi tri marker: {}".format(positions[:5]))

if count >= 3:
    print("SYNC_MARKER=FOUND")
    print("[OK] Sync marker hoat dong chinh xac!")
    print("[*] Ung dung: Sau khi bi cat/dich chuyen, decoder co the tim lai vi tri dung")
else:
    print("SYNC_MARKER=NOT_FOUND")
    print("[!] Khong tim thay du marker")
