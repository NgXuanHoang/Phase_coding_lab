#!/usr/bin/env python3
import numpy as np
from scipy.io import wavfile
import sys

SEGMENT_SIZE = 8192
START_BIN    = 100
N_COPIES     = 3
MESSAGE      = "ATTT PTIT"
KEY          = 42

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def get_bit(audio, seg_idx, bin_idx):
    s = seg_idx * SEGMENT_SIZE
    e = s + SEGMENT_SIZE
    if e > len(audio): return 0
    seg = audio[s:e].astype(np.float64)
    pha = np.angle(np.fft.fft(seg))
    return 1 if float(pha[bin_idx]) >= 0 else 0

input_file  = sys.argv[1] if len(sys.argv) > 1 else "stego_defended.wav"
output_file = sys.argv[2] if len(sys.argv) > 2 else "ber_defended.txt"
label       = sys.argv[3] if len(sys.argv) > 3 else "Defense"

rate, audio = wavfile.read(input_file)
if audio.ndim > 1:
    audio = audio.mean(axis=1).astype(np.int16)

orig_bits    = str_to_bits(MESSAGE)
num_bits     = len(orig_bits)
max_segments = len(audio) // SEGMENT_SIZE

# Cung logic segment nhu defend_embed.py
segments_per_copy = []
for copy_idx in range(N_COPIES):
    offset = copy_idx * num_bits
    segs = [(offset + bit_idx) % max_segments for bit_idx in range(num_bits)]
    segments_per_copy.append(segs)

# Trich xuat
copies = []
for copy_idx in range(N_COPIES):
    copy_bits = []
    for bit_idx in range(num_bits):
        seg_idx = segments_per_copy[copy_idx][bit_idx]
        copy_bits.append(get_bit(audio, seg_idx, START_BIN))
    copies.append(copy_bits)

# Majority Vote
final_bits = []
for i in range(num_bits):
    votes = [copies[c][i] for c in range(N_COPIES)]
    final_bits.append(1 if sum(votes) > N_COPIES//2 else 0)

errors = sum(o!=r for o,r in zip(orig_bits, final_bits))
ber    = errors / num_bits

if ber < 0.05:
    note = "Phong thu hieu qua"
elif ber < 0.3:
    note = "Phong thu co tac dung mot phan"
elif ber < 0.5:
    note = "Phong thu han che"
else:
    note = "Tan cong vuot qua phong thu"

print("[*] Label  : {}".format(label))
print("[*] Errors : {}/{}".format(errors, num_bits))
print("[*] BER    : {:.4f} ({:.1f}%)".format(ber, ber*100))
print("[*] Nhan xet: {}".format(note))

with open(output_file, "w") as f:
    f.write("ATTACK={}\n".format(label))
    f.write("BER={:.6f}\n".format(ber))
    f.write("BER_PERCENT={:.2f}\n".format(ber*100))
    f.write("ERRORS={}\n".format(errors))
    f.write("NOTE={}\n".format(note))

print("[OK] Defense {} BER: {:.4f} → {}".format(label, ber, output_file))
