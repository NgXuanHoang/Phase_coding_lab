#!/usr/bin/env python3
"""
embed_phase.py - Nhung tin bang Phase Coding (khong phong thu)
Su dung: python3 embed_phase.py
"""
import numpy as np
from scipy.io import wavfile

SEGMENT_SIZE = 8192
MESSAGE      = "LABTAINER"
START_BIN    = 100
INPUT_WAV    = "input.wav"
OUTPUT_WAV   = "stego_basic.wav"

def str_to_bits(s):
    return [int(b) for c in s for b in format(ord(c), '08b')]

def bits_to_str(bits):
    chars = []
    for i in range(0, len(bits) - 7, 8):
        byte = int(''.join(str(b) for b in bits[i:i+8]), 2)
        chars.append(chr(byte))
    return ''.join(chars)

def phase_embed(audio, message, segment_size, start_bin):
    bits = str_to_bits(message)
    segment   = audio[:segment_size].astype(np.float64)
    fft_data  = np.fft.fft(segment)
    magnitude = np.abs(fft_data)
    phase     = np.angle(fft_data)
    for i, bit in enumerate(bits):
        k = start_bin + i
        phase[k]              = np.pi/2 if bit == 1 else -np.pi/2
        phase[segment_size-k] = -phase[k]
    modified_fft     = magnitude * np.exp(1j * phase)
    modified_segment = np.real(np.fft.ifft(modified_fft))
    result = audio.copy().astype(np.float64)
    result[:segment_size] = modified_segment
    return result

def phase_extract(audio, num_chars, segment_size, start_bin):
    num_bits = num_chars * 8
    segment  = audio[:segment_size].astype(np.float64)
    fft_data = np.fft.fft(segment)
    phase    = np.angle(fft_data)
    bits = []
    for i in range(num_bits):
        k = start_bin + i
        bits.append(1 if phase[k] >= 0 else 0)
    return bits

def compute_ber(orig_bits, recv_bits):
    errors = sum(o != r for o, r in zip(orig_bits, recv_bits))
    return errors / len(orig_bits)

print("=== embed_phase.py: Phase Coding Co Ban (Khong Phong Thu) ===")
rate, audio = wavfile.read(INPUT_WAV)
audio = audio.astype(np.float32)
print("[*] Input : {} ({} Hz, {} samples)".format(INPUT_WAV, rate, len(audio)))

# Nhung tin
stego = phase_embed(audio, MESSAGE, SEGMENT_SIZE, START_BIN)
stego = np.clip(stego, -32768, 32767).astype(np.int16)
wavfile.write(OUTPUT_WAV, rate, stego)

# Kiem tra BER baseline
orig_bits = str_to_bits(MESSAGE)
recv_bits = phase_extract(stego.astype(np.float32), len(MESSAGE), SEGMENT_SIZE, START_BIN)
ber = compute_ber(orig_bits, recv_bits)

print("[OK] Stego : {}".format(OUTPUT_WAV))
print("[*] Message: '{}'".format(MESSAGE))
print("[*] Extract: '{}'".format(bits_to_str(recv_bits)))
print("BER_BASELINE={:.6f}".format(ber))

if ber == 0.0:
    print("[OK] Nhung tin thanh cong, BER = 0%")
else:
    print("[!] Canh bao: BER = {:.1f}%".format(ber*100))
